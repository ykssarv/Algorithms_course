package ee.ttu.algoritmid.trampoline;

public class HW02 implements TrampolineCenter {

    public int width;
    public int height;
    public Node[][] nodes;

    @Override
    public Result play(Trampoline[][] map) {
        makeMap(map);
        markLastAsSolved();
        solve(nodes[0][0]);
        return parseAnswer();
    }

    private ResultImplementation parseAnswer() {
        Node current = nodes[0][0];
        ResultImplementation result = new ResultImplementation();
        while (!(current.x == width - 1 && current.y == height - 1)) {
            if (current.jumpDistance == 0) {
                throw new RuntimeException("Jump distance should not be 0, this must be an invalid solution");
            }
            result.addJump(current.jumpEast, current.jumpDistance, current.type == Trampoline.Type.WITH_FINE ? current.jump : 0);
            int newX = current.x;
            int newY = current.y;
            if (current.jumpEast) {
                newX += current.jumpDistance;
            } else {
                newY += current.jumpDistance;
            }
            current = nodes[newY][newX];
        }
        return result;
    }

    public void markLastAsSolved() {
        Node last = nodes[height - 1][width - 1];
        last.canFindFinish = true;
        last.jumpsToFinish = 0;
        last.fineAmount = 0;
        last.hasBeenSolved = true;
    }

    private void solve(Node node) {
        Node bestNeighbour = null;
        for (Node neighbour: node.neighbours) {
            if (neighbour.x != width - 1 || neighbour.y != height - 1) {
                solve(neighbour);
            }
            if (!neighbour.canFindFinish) {
                continue;
            }
            if (
                bestNeighbour == null
                    || neighbour.jumpsToFinish < bestNeighbour.jumpsToFinish
                    || neighbour.jumpsToFinish == bestNeighbour.jumpsToFinish && neighbour.fineAmount < bestNeighbour.fineAmount
            ) {
                bestNeighbour = neighbour;
            }
        }

        if (bestNeighbour != null) {
            node.canFindFinish = true;
            node.jumpsToFinish = bestNeighbour.jumpsToFinish + 1;
            node.fineAmount = bestNeighbour.fineAmount + (node.type == Trampoline.Type.WITH_FINE ? node.jump : 0);
            node.jumpEast = bestNeighbour.y == node.y;
            node.jumpDistance = bestNeighbour.x - node.x + bestNeighbour.y - node.y;
        } else {
            node.canFindFinish = false;
        }
        node.hasBeenSolved = true;
    }

    private void makeMap(Trampoline[][] map) {
        this.height = map.length;
        this.width = map[0].length;
        nodes = new Node[this.height][this.width];
        for (int y = 0; y < this.height; y++) {
            for (int x = 0; x < this.width; x++) {
                nodes[y][x] = new Node(x, y, map[y][x].getJumpForce(), map[y][x].getType());
            }
        }
        for (int y = 0; y < this.height; y++) {
            for (int x = 0; x < this.width; x++) {
                addNeighbours(x, y);
            }
        }
    }

    public void addNeighbours(int x, int y) {
        int jumpForce = nodes[y][x].jump;

        // Add right
        for (int j = 1; j <= jumpForce + 1; j++) {
            int rightX = x + j;
            if (rightX >= width) {
                break;
            }
            if (nodes[y][rightX].type == Trampoline.Type.WALL) {
                if (rightX - 1 > x && j < jumpForce) {
                    addNeighbour(nodes[y][x], rightX - 1, y);
                }
                break;
            }
            if (Math.abs(j - jumpForce) <= 1) {
                addNeighbour(nodes[y][x], rightX, y);
            }
        }

        // Add down
        for (int j = 1; j <= jumpForce + 1; j++) {
            int downY = y + j;
            if (downY >= height) {
                break;
            }
            if (nodes[downY][x].type == Trampoline.Type.WALL) {
                if (downY - 1 > y && j < jumpForce) {
                    addNeighbour(nodes[y][x], x, downY - 1);
                }
                break;
            }
            if (Math.abs(j - jumpForce) <= 1) {
                addNeighbour(nodes[y][x], x, downY);
            }
        }
    }

    public void addNeighbour(Node node, int x, int y) {
        node.addNeighbour(nodes[y][x]);
    }
}
