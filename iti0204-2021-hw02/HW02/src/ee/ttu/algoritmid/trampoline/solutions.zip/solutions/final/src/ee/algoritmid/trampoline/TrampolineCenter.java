package ee.ttu.algoritmid.trampoline;

public interface TrampolineCenter {

    Result play(Trampoline[][] map);

}