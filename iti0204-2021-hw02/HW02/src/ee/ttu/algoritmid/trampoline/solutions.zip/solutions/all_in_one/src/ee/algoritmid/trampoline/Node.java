package ee.ttu.algoritmid.trampoline;

import java.util.Arrays;
import java.util.stream.Collectors;

public class Node {

    // Values related to trampoline
    public int distance;
    public int x;
    public int y;
    public int jump;
    public Trampoline.Type type;
    public Node[] neighbours;

    // Solution from here
    public int jumpsToFinish;
    public int fineAmount;
    public boolean canFindFinish;

    // Where to jump next
    public boolean jumpEast;
    public int jumpDistance;

    // Status
    public boolean neighboursAdded;

    // Stack related info
    public int jumpsSoFar;
    public int fineSoFar;

    // Useless variable to demonstrate no memoization on stack
    public boolean hasCome = false;

    public Node(int x, int y, int jump, Trampoline.Type type) {
        this.x = x;
        this.y = y;
        this.jump = jump;
        this.type = type;
        this.distance = x + y;
    }

    public void addNeighbours(Node[] right, Node[] down, int rightAmount, int downAmount, boolean stackMode) {
        int outCounter = 0;
        int rightCounter = stackMode ? 0 : rightAmount - 1;
        int downCounter = stackMode ? 0 : downAmount - 1;
        int mod = stackMode ? 1 : -1;
        this.neighbours = new Node[rightAmount + downAmount];

        // Combine two sorted arrays into one sorted array
        while (stackMode && rightCounter < rightAmount && downCounter < downAmount || !stackMode && rightCounter >= 0 && downCounter >= 0) {
            Node rightNode = right[rightCounter];
            Node downNode = down[downCounter];
            if (stackMode && rightNode.distance < downNode.distance || !stackMode && rightNode.distance >= downNode.distance) {
                this.neighbours[outCounter] = right[rightCounter];
                rightCounter += mod;
            } else {
                this.neighbours[outCounter] = down[downCounter];
                downCounter += mod;
            }
            outCounter++;
        }

        while (stackMode && rightCounter < rightAmount || !stackMode && rightCounter >= 0) {
            this.neighbours[outCounter] = right[rightCounter];
            outCounter++;
            rightCounter += mod;
        }

        while (stackMode && downCounter < downAmount || !stackMode && downCounter >= 0) {
            this.neighbours[outCounter] = down[downCounter];
            outCounter++;
            downCounter += mod;
        }
    }
}
