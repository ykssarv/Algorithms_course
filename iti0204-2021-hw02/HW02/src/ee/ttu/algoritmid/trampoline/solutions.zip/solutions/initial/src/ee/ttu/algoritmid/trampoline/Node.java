package ee.ttu.algoritmid.trampoline;

import java.util.ArrayList;
import java.util.List;

public class Node {

    public int x;
    public int y;
    public int jump;
    public Trampoline.Type type;
    public List<Node> neighbours;

    public int jumpsToFinish;
    public int fineAmount;
    public boolean canFindFinish;
    public boolean hasBeenSolved;
    public boolean jumpEast;
    public int jumpDistance;

    public Node(int x, int y, int jump, Trampoline.Type type) {
        this.x = x;
        this.y = y;
        this.jump = jump;
        this.type = type;
        neighbours = new ArrayList<>();
        this.hasBeenSolved = false;
    }

    public void addNeighbour(Node node) {
        neighbours.add(node);
    }
}
