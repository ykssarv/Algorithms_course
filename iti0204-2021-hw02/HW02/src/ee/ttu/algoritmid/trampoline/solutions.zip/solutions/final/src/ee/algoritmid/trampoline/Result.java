package ee.ttu.algoritmid.trampoline;

import java.util.List;

public interface Result {

    List<String> getJumps();

    int getTotalFine();

}
